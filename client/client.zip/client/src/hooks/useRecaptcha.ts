import { useCallback, useEffect } from 'react';

const SITE_KEY = import.meta.env.VITE_RECAPTCHA_SITE_KEY as string | undefined;

declare global {
  interface Window {
    grecaptcha: {
      ready: (cb: () => void) => void;
      execute: (siteKey: string, options: { action: string }) => Promise<string>;
    };
  }
}

/**
 * Loads the reCAPTCHA v3 script once and exposes `getToken(action)`.
 *
 * If VITE_RECAPTCHA_SITE_KEY is not set (local dev without keys),
 * getToken() returns an empty string and verification is skipped server-side.
 */
export function useRecaptcha() {
  useEffect(() => {
    if (!SITE_KEY) return;
    if (document.getElementById('recaptcha-script')) return;

    const script = document.createElement('script');
    script.id = 'recaptcha-script';
    script.src = `https://www.google.com/recaptcha/api.js?render=${SITE_KEY}`;
    script.async = true;
    document.head.appendChild(script);
  }, []);

  const getToken = useCallback(
    async (action: 'login' | 'register'): Promise<string> => {
      if (!SITE_KEY) return '';

      return new Promise((resolve) => {
        window.grecaptcha.ready(async () => {
          try {
            const token = await window.grecaptcha.execute(SITE_KEY, { action });
            resolve(token);
          } catch {
            resolve(''); // fail open — server also fails open on network error
          }
        });
      });
    },
    []
  );

  return { getToken };
}
