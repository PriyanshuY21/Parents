import { Request, Response, NextFunction } from 'express';

const RECAPTCHA_SECRET = process.env.RECAPTCHA_SECRET_KEY ?? '';
const RECAPTCHA_MIN_SCORE = parseFloat(process.env.RECAPTCHA_MIN_SCORE ?? '0.5');
const RECAPTCHA_VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';

/**
 * Verifies a Google reCAPTCHA v3 token sent in the request body as `recaptchaToken`.
 * Rejects requests with a score below RECAPTCHA_MIN_SCORE (default 0.5).
 *
 * Skip verification when RECAPTCHA_SECRET_KEY is not set (e.g. local dev without keys).
 */
export async function verifyRecaptcha(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  // Allow bypassing in dev when secret not configured
  if (!RECAPTCHA_SECRET) {
    next();
    return;
  }

  const token = req.body?.recaptchaToken as string | undefined;

  if (!token) {
    res.status(400).json({ error: 'Missing reCAPTCHA token.' });
    return;
  }

  try {
    const params = new URLSearchParams({
      secret: RECAPTCHA_SECRET,
      response: token,
      remoteip: (req.ip ?? '').replace('::ffff:', ''),
    });

    const response = await fetch(`${RECAPTCHA_VERIFY_URL}?${params.toString()}`, {
      method: 'POST',
    });

    if (!response.ok) {
      throw new Error(`reCAPTCHA API returned HTTP ${response.status}`);
    }

    const data = (await response.json()) as {
      success: boolean;
      score: number;
      action: string;
      'error-codes'?: string[];
    };

    if (!data.success) {
      const logger = req.app.locals.logger;
      logger?.warn({ event: 'recaptcha_failed', codes: data['error-codes'], ip: req.ip });
      res.status(400).json({ error: 'reCAPTCHA verification failed. Please try again.' });
      return;
    }

    if (data.score < RECAPTCHA_MIN_SCORE) {
      const logger = req.app.locals.logger;
      logger?.warn({ event: 'recaptcha_low_score', score: data.score, ip: req.ip });
      res.status(403).json({ error: 'Request blocked: suspicious activity detected.' });
      return;
    }

    // Attach score to request for optional downstream inspection
    (req as Request & { recaptchaScore?: number }).recaptchaScore = data.score;
    next();
  } catch (err) {
    const logger = req.app.locals.logger;
    logger?.error({ event: 'recaptcha_error', message: (err as Error).message });
    // Fail open on network errors so a Google outage doesn't lock users out.
    // Change to `res.status(503).json(...)` if you prefer fail-closed.
    next();
  }
}
