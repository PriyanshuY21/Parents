import express, { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { body } from 'express-validator';
import { AuthController } from '../controllers/authController';
import { requireAuth } from '../middleware/auth';
import { verifyRecaptcha } from '../middleware/recaptcha';

const router: Router = express.Router();

// ── Rate limits ───────────────────────────────────────────────────────────────
// Login: 10 attempts per 15 min to slow brute-force
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Please wait 15 minutes before trying again.' },
});

// Register: 5 per hour — prevents bulk account creation
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many registration attempts. Please try again in an hour.' },
});

// ── Validators ────────────────────────────────────────────────────────────────
const registerValidators = [
  body('email').isEmail().normalizeEmail(),
  body('password')
    .isLength({ min: 8 })
    .matches(/[A-Z]/).withMessage('Must contain uppercase')
    .matches(/[0-9]/).withMessage('Must contain a number'),
  body('name').trim().isLength({ min: 2, max: 80 }),
  body('recaptchaToken').optional().isString(),
];

const loginValidators = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
  body('recaptchaToken').optional().isString(),
];

// ── Routes ────────────────────────────────────────────────────────────────────
router.post(
  '/register',
  registerLimiter,
  registerValidators,
  verifyRecaptcha,
  AuthController.register
);

router.post(
  '/login',
  loginLimiter,
  loginValidators,
  verifyRecaptcha,
  AuthController.login
);

router.get('/me', requireAuth, AuthController.me);

export default router;
