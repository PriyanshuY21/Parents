import express, { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { HistoryController } from '../controllers/historyController';
import { requireAuth } from '../middleware/auth';

const router: Router = express.Router();

// 60 reads per 15 min per user — history is cheap but we still throttle
const historyReadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please slow down.' },
});

// 30 writes/deletes per 15 min per user
const historyWriteLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many history operations. Please slow down.' },
});

router.get('/',        requireAuth, historyReadLimiter,  HistoryController.getAll);
router.post('/',       requireAuth, historyWriteLimiter, HistoryController.create);
router.delete('/:id',  requireAuth, historyWriteLimiter, HistoryController.deleteOne);
router.delete('/',     requireAuth, historyWriteLimiter, HistoryController.deleteAll);

export default router;
